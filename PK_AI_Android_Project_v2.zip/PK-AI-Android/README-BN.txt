PK AI Assistant — Android project source
========================================

এটি Android অ্যাপের সোর্স প্রজেক্ট; APK ফাইল নয়।

ফিচার:
- বাংলা/ইংরেজি চ্যাট UI
- Android Speech Recognizer দিয়ে কথা ইনপুট
- Android Text-to-Speech দিয়ে উত্তর পড়ে শোনানো
- সময়, তারিখ, সাহায্য ও সাধারণ হিসাবের মতো কিছু অফলাইন কমান্ড
- অনলাইন ChatGPT/API সংযোগ এখনো যুক্ত নয়

মোবাইল থেকে APK তৈরি:
1. Code on the Go ইনস্টল করুন: https://appdevforall.org/code-on-the-go/
2. অন্তত 3.5GB ফাঁকা স্টোরেজ রাখুন; প্রথম সেটআপে Wi-Fi ব্যবহার করুন।
3. ZIP extract করুন।
4. Code on the Go-তে Open Existing Project দিয়ে PK-AI-Android ফোল্ডার খুলুন।
5. Gradle sync শেষ হলে Build/Run থেকে Debug APK তৈরি করুন।
6. তৈরি APK ইনস্টল করুন এবং Microphone permission দিন।

গুরুত্বপূর্ণ:
- 6GB মোট RAM ভালো শুরু, কিন্তু IDE/build চলার সময় প্রায় 4GB ফ্রি RAM থাকলে সুবিধা।
- বাংলা TTS voice ফোনের Text-to-Speech settings-এ ডাউনলোড/সক্রিয় থাকতে হবে।
- Speech Recognition সেবার জন্য ইন্টারনেট লাগতে পারে।
- API key সরাসরি অ্যাপের মধ্যে রাখবেন না। Online AI-এর জন্য নিরাপদ backend দরকার।
- এটি starter project, production-ready বা Play Store-ready নয়।
